package urltest

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"sync"
	"time"

	"github.com/sagernet/sing-box/adapter"
	C "github.com/sagernet/sing-box/constant"
	"github.com/sagernet/sing/common"
	M "github.com/sagernet/sing/common/metadata"
	N "github.com/sagernet/sing/common/network"
	"github.com/sagernet/sing/common/ntp"
	"github.com/sagernet/sing/common/observable"
)

// A status-aware probe must consume the response so TLS integrity failures
// after the headers are visible. It must not, however, turn a health check into
// an unbounded download when a configured endpoint changes behaviour.
const maxVerifiedResponseBody = 262_144

type ResponseValidator func(status int, body []byte) error

type HistoryStorage struct {
	access       sync.RWMutex
	delayHistory map[string]*adapter.URLTestHistory
	updateHooks  []*observable.Subscriber[struct{}]
}

func NewHistoryStorage() *HistoryStorage {
	return &HistoryStorage{
		delayHistory: make(map[string]*adapter.URLTestHistory),
	}
}

func (s *HistoryStorage) AddUpdateHook(hook *observable.Subscriber[struct{}]) {
	s.access.Lock()
	defer s.access.Unlock()
	s.updateHooks = append(s.updateHooks, hook)
}

func (s *HistoryStorage) NotifyUpdated() {
	s.access.RLock()
	defer s.access.RUnlock()
	s.notifyUpdated()
}

func (s *HistoryStorage) LoadURLTestHistory(tag string) *adapter.URLTestHistory {
	if s == nil {
		return nil
	}
	s.access.RLock()
	defer s.access.RUnlock()
	return s.delayHistory[tag]
}

func (s *HistoryStorage) DeleteURLTestHistory(tag string) {
	s.access.Lock()
	delete(s.delayHistory, tag)
	s.notifyUpdated()
	s.access.Unlock()
}

func (s *HistoryStorage) StoreURLTestHistory(tag string, history *adapter.URLTestHistory) {
	s.access.Lock()
	s.delayHistory[tag] = history
	s.notifyUpdated()
	s.access.Unlock()
}

func (s *HistoryStorage) notifyUpdated() {
	for _, updateHook := range s.updateHooks {
		updateHook.Emit(struct{}{})
	}
}

func (s *HistoryStorage) Close() error {
	s.access.Lock()
	defer s.access.Unlock()
	s.updateHooks = nil
	return nil
}

func URLTest(ctx context.Context, link string, detour N.Dialer) (uint16, error) {
	delay, _, err := urlTestSequence(ctx, link, detour, false, nil)
	return delay, err
}

// URLTestWithStatus is the status-aware form used by policy groups that must
// distinguish a reachable web server from a service that rejected the exit
// country. The ordinary URLTest deliberately keeps its historical behaviour
// for callers that only need transport reachability.
func URLTestWithStatus(ctx context.Context, link string, detour N.Dialer) (uint16, int, error) {
	return urlTestSequence(ctx, link, detour, true, nil)
}

// URLTestWithResponseValidator gives a service-aware caller a bounded response
// body for exact validation. The body is never returned, logged, or retained.
func URLTestWithResponseValidator(ctx context.Context, link string, detour N.Dialer, validator ResponseValidator) (uint16, int, error) {
	return urlTestSequence(ctx, link, detour, true, validator)
}

func urlTestSequence(ctx context.Context, link string, detour N.Dialer, verifyResponse bool, validator ResponseValidator) (uint16, int, error) {
	multiplexOutbound, isMultiplexOutbound := common.Cast[adapter.OutboundWithMultiplex](detour)
	if isMultiplexOutbound && multiplexOutbound.MultiplexEnabled() {
		_, _, err := urlTest(ctx, link, detour, verifyResponse, validator)
		if err != nil {
			return 0, 0, err
		}
	}
	return urlTest(ctx, link, detour, verifyResponse, validator)
}

func urlTest(ctx context.Context, link string, detour N.Dialer, verifyResponse bool, validator ResponseValidator) (t uint16, status int, err error) {
	if link == "" {
		link = "https://www.gstatic.com/generate_204"
	}
	linkURL, err := url.Parse(link)
	if err != nil {
		return
	}
	hostname := linkURL.Hostname()
	port := linkURL.Port()
	if port == "" {
		switch linkURL.Scheme {
		case "http":
			port = "80"
		case "https":
			port = "443"
		}
	}

	start := time.Now()
	instance, err := detour.DialContext(ctx, "tcp", M.ParseSocksaddrHostPortStr(hostname, port))
	if err != nil {
		return
	}
	defer instance.Close()
	if N.NeedHandshakeForWrite(instance) {
		start = time.Now()
	}
	method := http.MethodHead
	if verifyResponse {
		// Reading the full body is intentional: a corrupt TLS record can arrive
		// after the headers, so a HEAD-only latency check would mark the same
		// tunnel healthy even while ChatGPT downloads fail with bad record MAC.
		method = http.MethodGet
	}
	req, err := http.NewRequest(method, link, nil)
	if err != nil {
		return
	}
	client := http.Client{
		Transport: &http.Transport{
			DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
				return instance, nil
			},
			TLSClientConfig: &tls.Config{
				Time:    ntp.TimeFuncFromContext(ctx),
				RootCAs: adapter.RootPoolFromContext(ctx),
			},
		},
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
		Timeout: C.TCPTimeout,
	}
	defer client.CloseIdleConnections()
	resp, err := client.Do(req.WithContext(ctx))
	if err != nil {
		return
	}
	status = resp.StatusCode
	if verifyResponse {
		var body []byte
		if validator == nil {
			err = drainVerifiedResponse(resp.Body)
		} else {
			body, err = readVerifiedResponse(resp.Body)
		}
		if err != nil {
			resp.Body.Close()
			return
		}
		if validator != nil {
			if err = validator(status, body); err != nil {
				resp.Body.Close()
				return
			}
		}
	}
	if err = resp.Body.Close(); err != nil {
		return
	}
	t = uint16(time.Since(start) / time.Millisecond)
	return
}

func readVerifiedResponse(body io.Reader) ([]byte, error) {
	value, err := io.ReadAll(io.LimitReader(body, maxVerifiedResponseBody+1))
	if err != nil {
		return nil, err
	}
	if len(value) > maxVerifiedResponseBody {
		return nil, fmt.Errorf("verified response exceeds %d bytes", maxVerifiedResponseBody)
	}
	return value, nil
}

func drainVerifiedResponse(body io.Reader) error {
	_, err := io.CopyN(io.Discard, body, maxVerifiedResponseBody+1)
	switch {
	case err == nil:
		return fmt.Errorf("verified response exceeds %d bytes", maxVerifiedResponseBody)
	case errors.Is(err, io.EOF):
		return nil
	default:
		return err
	}
}
