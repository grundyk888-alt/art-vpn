package urltest

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	N "github.com/sagernet/sing/common/network"
)

func testContext(t *testing.T) context.Context {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	t.Cleanup(cancel)
	return ctx
}

func TestURLTestWithStatusUsesGetAndAcceptsExpected401Response(t *testing.T) {
	var access sync.Mutex
	var methods []string
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		access.Lock()
		methods = append(methods, request.Method)
		access.Unlock()
		writer.WriteHeader(http.StatusUnauthorized)
		_, _ = writer.Write([]byte("authentication required"))
	}))
	defer server.Close()

	_, status, err := URLTestWithStatus(testContext(t), server.URL, N.SystemDialer)
	if err != nil {
		t.Fatalf("status-aware probe failed: %v", err)
	}
	if status != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401", status)
	}
	access.Lock()
	defer access.Unlock()
	if len(methods) != 1 || methods[0] != http.MethodGet {
		t.Fatalf("methods = %v, want one GET", methods)
	}
}

func TestLegacyURLTestKeepsHeadMethod(t *testing.T) {
	method := make(chan string, 1)
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		method <- request.Method
		writer.WriteHeader(http.StatusNoContent)
	}))
	defer server.Close()

	if _, err := URLTest(testContext(t), server.URL, N.SystemDialer); err != nil {
		t.Fatalf("legacy probe failed: %v", err)
	}
	if observed := <-method; observed != http.MethodHead {
		t.Fatalf("method = %q, want HEAD", observed)
	}
}

func TestURLTestWithStatusRejectsTruncatedResponseBody(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		writer.Header().Set("Content-Length", "100")
		writer.WriteHeader(http.StatusOK)
		_, _ = writer.Write([]byte("short"))
	}))
	defer server.Close()

	if _, _, err := URLTestWithStatus(testContext(t), server.URL, N.SystemDialer); err == nil {
		t.Fatal("truncated response body must fail the health probe")
	}
}

func TestURLTestWithStatusRejectsUnboundedResponseBody(t *testing.T) {
	payload := strings.Repeat("x", maxVerifiedResponseBody+1)
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		writer.WriteHeader(http.StatusOK)
		_, _ = writer.Write([]byte(payload))
	}))
	defer server.Close()

	if _, _, err := URLTestWithStatus(testContext(t), server.URL, N.SystemDialer); err == nil {
		t.Fatal("response larger than the verification budget must fail")
	}
}

func TestURLTestWithResponseValidatorIsBoundedAndFailClosed(t *testing.T) {
	payload := strings.Repeat("x", maxVerifiedResponseBody+1)
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		writer.WriteHeader(http.StatusOK)
		_, _ = writer.Write([]byte(payload))
	}))
	defer server.Close()

	called := false
	_, _, err := URLTestWithResponseValidator(testContext(t), server.URL, N.SystemDialer, func(int, []byte) error {
		called = true
		return nil
	})
	if err == nil {
		t.Fatal("oversized policy response must fail")
	}
	if called {
		t.Fatal("validator must not receive an oversized body")
	}
}
